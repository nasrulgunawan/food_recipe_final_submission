class Foods {
  final String id;
  final String meal;
  final String image;

  Foods({this.id, this.meal, this.image});

  factory Foods.fromJson(Map<String, dynamic> json) {

    return Foods(
      id: json['idMeal'],
      meal: json['strMeal'],
      image: json['strMealThumb']
    );
  }
}
