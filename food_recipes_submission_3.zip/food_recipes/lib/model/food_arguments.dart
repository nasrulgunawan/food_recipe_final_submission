class FoodArguments {
  final String id;

  FoodArguments(this.id);
}