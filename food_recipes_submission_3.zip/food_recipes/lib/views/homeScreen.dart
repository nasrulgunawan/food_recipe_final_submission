import 'package:flutter/material.dart';
import 'package:food_recipes/views/menu.dart';
import 'package:food_recipes/views/about.dart';

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _currentIndex = 0;

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  final List _content = [
    new Menu(type: 'seafood'),
    new Menu(type: 'dessert'),
    new About()
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: _content[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        onTap: onTabTapped,
        currentIndex: _currentIndex,
        items: [
          BottomNavigationBarItem(
            icon: new Icon(Icons.fastfood),
            title: new Text('Seafood'),
          ),
          BottomNavigationBarItem(
            icon: new Icon(Icons.cake),
            title: new Text('Dessert'),
          ),
          BottomNavigationBarItem(
              icon: Icon(Icons.person),
              title: Text('About')
          )
        ],
      ),
    );
  }
}
