import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:food_recipes/views/detail/detail_screen.dart';
import 'package:food_recipes/network/response.dart';
import 'package:food_recipes/model/food_arguments.dart';


class Menu extends StatefulWidget {
  Menu({Key key, this.type}) : super(key: key);
  final String type;

  @override
  _MenuState createState() => _MenuState();
}

class _MenuState extends State<Menu> {
  Widget _mealThumb(data) {
    return Hero(
      tag: "hero-${data.id}",
      child: ClipRRect(
        borderRadius: BorderRadius.all(Radius.circular(10)),
        child: CachedNetworkImage(
          imageUrl: data.image,
          placeholder: (context, url) => Container(
            padding: EdgeInsets.all(50),
            child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation(Colors.pink))
          ),
          errorWidget: (context, url, error) => Icon(Icons.error),
        ),
      ),
    );
  }

  Widget _mealName(data) {
    return Container(
      padding: EdgeInsets.all(10),
      child: Text(
        data.meal,
        style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: Colors.white),
        textAlign: TextAlign.center,
      ),
    );
  }

  Widget _menu() {
    return Container(
      child: FutureBuilder(
          future: Response().fetchFood(widget.type),
          builder: (context, snapshot) {
            print(snapshot.data);
            if (snapshot.hasData) {
              return GridView.builder(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2),
                  itemCount: snapshot.data.length,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      child: Card(
                        elevation: 2.0,
                        shape: RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(20))),
                        margin: EdgeInsets.all(10),
                        child: Stack(
                          children: <Widget>[
                            Positioned.fill(child: _mealThumb(snapshot.data[index])),
                            Positioned(
                              bottom: 0,
                              left: 0,
                              right: 0,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Color.fromRGBO(0, 0, 0, 0.3),
                                  borderRadius: BorderRadius.only(
                                      bottomLeft: Radius.circular(10),
                                      bottomRight: Radius.circular(10)),
                                ),
                                child: _mealName(snapshot.data[index]),
                              ),
                            )
                          ],
                        ),
                      ),
                      onTap: () => _goToDetail(context, snapshot.data[index]),
                    );
                  });
            } else if (snapshot.hasError) {
              return Center(child: Text("Gagal memuat data"));
            }

            return Center(child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation(Colors.pink)));
          }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _menu(),
    );
  }
}

void _goToDetail(context, data) {
  final snackBar = SnackBar(content: Text("Recipe: ${data.meal} Clicked!"));

  Navigator.pushNamed(context, DetailScreen.routeName,
      arguments: FoodArguments(data.id));

  Scaffold.of(context)
      ..removeCurrentSnackBar()
      ..showSnackBar(snackBar);
}
