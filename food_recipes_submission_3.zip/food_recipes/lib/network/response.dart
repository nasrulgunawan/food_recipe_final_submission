import 'package:http/http.dart' as http;
import 'package:food_recipes/model/foods.dart';
import 'package:food_recipes/model/food_detail.dart';
import 'dart:convert';

class Response {
  fetchFood(String endpoint) async {
    String dataURL = "https://www.themealdb.com/api/json/v1/1/filter.php?c=$endpoint";
    final response = await http.get(dataURL);

    var responseJson = json.decode(response.body);
    if (response.statusCode == 200) {
      var foods = (responseJson['meals'] as List)
          .map((f) => Foods.fromJson(f))
          .toList();
      return foods;
    } else {
      throw Exception("Failed to load $endpoint menu");
    }
  }

  fetchFoodDetail(String id) async {
    String dataURL = "https://www.themealdb.com/api/json/v1/1/lookup.php?i=$id";
    final response = await http.get(dataURL);

    var responseJson = json.decode(response.body);
    if (response.statusCode == 200) {
      var detail = (responseJson['meals'] as List)
          .map((f) => FoodDetail.fromJson(f))
          .toList();
      return detail;
    } else {
      throw Exception("Gagal memuat data detail");
    }
  }
}